using barArcadeGame;
using barArcadeGame.View;
using Games.Files;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Games
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            //ZzInitializeComponent();

            database.InitializeDatabase();
            //database.coinfaker();
            database.highscorefaker();
        }

        private void Frame_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void exitClick(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void highClick(object sender, RoutedEventArgs e)
        {
            LoadPlayerScores();
        }

        private void gameClick(object sender, RoutedEventArgs e)
        {
            if (!Name.Text.Equals("Enter a Username"))
            {
                var game = new Game1(Name.Text);
                game.Run();
            }
            else
            {
                MessageBox.Show("Please enter your name before playing.", "Input Required", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public void NavigateToMainWindow()
        {
           
        }

        private void LoadPlayerScores()
        {
            var (username, highscore) = database.GetHighscore();

            HighscoreLabel.Content =$"Current Best User-> Username: {username}, Highscore: {highscore}";
        }

    }
}
