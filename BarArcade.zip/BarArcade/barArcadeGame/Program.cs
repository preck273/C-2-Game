﻿
using var game = new barArcadeGame.View.Game1("name");
game.Run();
